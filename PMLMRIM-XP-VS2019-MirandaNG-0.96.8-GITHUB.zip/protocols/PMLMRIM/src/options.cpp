﻿#include "stdafx.h"
class CMrimAccountDlg : public CProtoDlgBase<CMrimProto> {
 CCtrlEdit email,password,server,port,avatarServer,avatarPort;
public:
 CMrimAccountDlg(CMrimProto* p,int id):CProtoDlgBase<CMrimProto>(p,id),
 email(this,IDC_EMAIL),password(this,IDC_PASSWORD),server(this,IDC_SERVER),port(this,IDC_PORT),avatarServer(this,IDC_AVATAR_SERVER),avatarPort(this,IDC_AVATAR_PORT){
 CreateLink(email,"Email",L"");
 CreateLink(password,"Password",L"");
 CreateLink(server,p->m_server);
 CreateLink(port,p->m_port);
 CreateLink(avatarServer,p->m_avatarServer);
 CreateLink(avatarPort,p->m_avatarPort);
 }
};
MWindow CMrimProto::OnCreateAccMgrUI(MWindow parent){auto* d=new CMrimAccountDlg(this,IDD_ACCMGRUI);d->SetParent(parent);d->Show();return d->GetHwnd();}
int CMrimProto::OnOptionsInit(WPARAM w,LPARAM){OPTIONSDIALOGPAGE o={};o.flags=ODPF_UNICODE;o.szGroup.w=LPGENW("Network");o.szTitle.w=m_tszUserName;o.position=1;o.pDialog=new CMrimAccountDlg(this,IDD_OPTIONS);g_plugin.addOptions(w,&o);return 0;}
